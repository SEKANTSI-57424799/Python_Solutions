print("-- CHALLENGE ONE SOLUTION --")
print("hello, world!")

print("-- CHALLENGE TWO SOLUTION --")
n = int(input())
if n % 2 == 0:
    if n in range(2, 6):
        print("Not Weird")

    elif n in range(6, 21):
        print("Weird")

    elif n > 20:
        print("Not Weird")
else:
    print("Weird")

print("-- CHALLENGE THREE SOLUTION --")
if __name__ == '__main__':
    a = int(input())
b = int(input())

print(a + b)
print(a - b)
print(a * b)

print("-- CHALLENGE FOUR SOLUTION --")
if __name__ == '__main__':
    a = int(input())
b = int(input())

print(a // b)
print(a / b)
