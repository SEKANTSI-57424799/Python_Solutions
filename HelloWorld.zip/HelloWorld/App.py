name = input('ENTER YOUR NAME: ')
print('Hi ' + name)

birth_year = input('ENTER BIRTH YEAR: ')
print(type(birth_year))
age = 2021 - int(birth_year)
print(type(age))
print(age)

print('CONVERTING POUNDS TO KILOGRAMS')

weight_lbs = input('ENTER THE WEIGHT IN POUNDS: ')
weight_kg = int(weight_lbs) * 0.45
print('This is his ' + str(weight_kg))